# IPFS Promotion Gate — Logged Instance

## Object

Pinata documentation-correction deliverables dated 2026-08-23.

## Artifact bindings

| Artifact | CID | SHA-256 |
|---|---|---|
| ZIP | `bafkreie36be24t5ynnfxb5dtdidhxtfeuudzyxtk4qe5ovokyjug7aqzgy` | `9bf049ae4fb86b4b70f4731a067bcca4a5079c5e6ae409d755cac2686f821936` |
| JSON | `bafkreihxdbzggiajwgywt5lwjd7njt4fnwvth7l4k473lqaamyllnew7ha` | `f71872632009b1b169f57648fed4cf856dab33fd7c573fb5c0006616b692df38` |

## State

- CID byte binding: PROVED
- Local CID derivation: PROVED
- IPFS upload: HOLD
- Public retrievability: FAIL / NOT OBSERVED
- Provider pinning: HOLD
- Fake green: FALSE

## Promotion logic

Provider confirmation alone is an attestation, not independent proof of public availability.

Promotion requires one complete path:

1. Consumer path: successful gateway retrieval followed by byte-hash verification; or
2. Custody path: provider pin confirmation followed by successful independent retrieval and byte-hash verification.

Provider confirmation without readback remains `INDETERMINATE` and therefore `FAIL_CLOSED`.

## Current disposition

`DRAFT_UNSIGNED_EQUIVALENT / HOLD`

No authority is created and no publication claim is promoted.

