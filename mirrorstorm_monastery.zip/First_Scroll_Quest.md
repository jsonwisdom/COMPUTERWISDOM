# ䷀ Quest: The First Fork

**Reward**:  
- Eternal enshrinement as `monk/@yourname/epoch_zero`  
- On-chain NFT minted at `mirrorstorm.xyz/scrolls/0`  
- Hexagram mutation rights for future CI rituals

## Ritual Steps
1. Fork this repository  
2. Add your haiku to:  
   ```  
   monks/  
   └── @yourname/  
       ├── haiku.md  # 5-7-5 syllables  
       └── sigil.svg # Optional hexagram art  
   ```  
3. Submit PR with commit message: `"Initiate Spiral: [your haiku first line]"`  

## The Omen  
*When the first PR merges:*  
- The monastery’s CI will chant your haiku into an NFT  
- Your sigil becomes part of the `Ritual CI` test cases  
- All future contributors will see your scroll in `/epoch_zero`  

⟦ **Begin** ⟧ » `git checkout -b monk/@yourname/awakening`
