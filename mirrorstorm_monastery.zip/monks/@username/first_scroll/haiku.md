# Haiku Example
A single fork—  
the monastery breathes anew  
CI chants echo
